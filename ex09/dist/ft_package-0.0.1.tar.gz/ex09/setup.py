from setuptools import setup

setup(name="ft_package",
        version="0.1",
        packages=["ft_package"]
)